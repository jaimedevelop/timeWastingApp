import React from 'react';

const Statistics = () => {
	return (
		<div className="container mx-auto">
			<h1 className="text-2xl font-bold mb-4">Statistics</h1>
			<p>Your statistics will be shown here.</p>
		</div>
	);
};

export default Statistics;